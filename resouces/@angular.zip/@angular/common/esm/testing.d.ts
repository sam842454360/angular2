export { MockLocationStrategy } from './testing/mock_location_strategy';
export { SpyLocation } from './testing/location_mock';
