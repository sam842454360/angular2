/**
 * This module exists in Dart, but not in Typescript. This exported symbol
 * is only here to help Typescript think this is a module.
 */
export declare var workaround_empty_observable_list_diff: any;
