import { LifecycleHooks } from '../core_private';
export declare function hasLifecycleHook(lcInterface: LifecycleHooks, token: any): boolean;
