import { TemplateAst } from '../template_ast';
import { CompileView } from './compile_view';
export declare function bindView(view: CompileView, parsedTemplate: TemplateAst[]): void;
